
if(1===1) {
    let nameSet = new Set();

    if (1 === 2) {
        // do nothing
    }
    else {

        function getArrayFromOl() {
            console.log('nameSet:', nameSet)
        }

        getArrayFromOl()
    }
}
